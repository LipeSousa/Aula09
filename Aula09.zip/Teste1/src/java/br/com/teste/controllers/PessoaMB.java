
package br.com.teste.controllers;

import br.com.teste.models.Pessoa;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.faces.view.ViewScoped;



@Named(value = "pessoaMB")
@ViewScoped
public class PessoaMB implements Serializable {
    
    private Pessoa pessoa = new Pessoa ();
    private List<Pessoa> pessoaLista = new ArrayList<>();
    
    public PessoaMB() {
        
    }
    
    public Pessoa getPessoa() {
        return pessoa;
    }
    
    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
    
    public List<Pessoa> getPessoaLista() {
        return pessoaLista;
    }
    
    public void setPessoaLista(List<Pessoa> pessoaLista) {
        this.pessoaLista = pessoaLista;
    }
    
    public void salvarPessoa() {
        pessoaLista.add(pessoa);
        pessoa = new Pessoa();
    }
}
